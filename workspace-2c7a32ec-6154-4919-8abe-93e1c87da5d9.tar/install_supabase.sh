# Instalar el cliente de Supabase
npm install @supabase/supabase-js

# Instalar tipos de TypeScript para Supabase
npm install @supabase/auth-helpers-nextjs @supabase/auth-helpers-react